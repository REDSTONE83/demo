<template>
	<div id="app">
		<h1>FINE?</h1>
	</div>
</template>

<script>
export default {
}
</script>

<style scoped>
#app {
	max-width: 400px;
	margin: 0 auto;
	line-height: 1.4;
	font-family: 'Avenir', Helvetica, Arial, sans-serif;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	color: blue;
}

h1 {
	text-align: center;
}
</style>