import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

var PageComponent = Vue.extend(App)

new PageComponent({
  propsData: initProps
}).$mount('#app')