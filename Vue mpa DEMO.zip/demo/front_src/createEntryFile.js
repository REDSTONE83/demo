const fs = require('fs')
const glob = require('glob')

const srcPath = '/Users/hongseokkang/Desktop/STUDY/demo/front_src/src/'
const buildPath = '/Users/hongseokkang/Desktop/STUDY/demo/front_src/build/'

var deleteFolderRecursive = function(path) {
    if( fs.existsSync(path) ) {
        fs.readdirSync(path).forEach(function(file,index){
        var curPath = path + "/" + file;
        if(fs.lstatSync(curPath).isDirectory()) { // recurse
            deleteFolderRecursive(curPath);
        } else { // delete file
            fs.unlinkSync(curPath);
        }
        });
        fs.rmdirSync(path);
    }
};

deleteFolderRecursive(buildPath)
fs.mkdirSync(buildPath)

const originContent = fs.readFileSync(srcPath.concat('index.js'), {encoding: 'utf8'})

glob.sync(srcPath.concat('*/*.vue')).forEach((path) => {

    const filePath = path.replace(srcPath,'')
    const pageName = filePath.split('/')[0]
    console.log(pageName)

    const content = originContent.replace('./App','../src/' + pageName + '/' + pageName)

    fs.writeFileSync(buildPath.concat(pageName + '.js'),Buffer.from(content, {encoding: 'utf8'}))

}, {})