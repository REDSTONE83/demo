const fs = require('fs')
const glob = require('glob')
const VueLoaderPlugin = require('vue-loader/lib/plugin')

//entry.js 파일 동적 생성
const srcPath = './src/'
const buildPath = './build/'

var deleteFolderRecursive = function(path) {
    if( fs.existsSync(path) ) {
        fs.readdirSync(path).forEach(function(file,index){
        var curPath = path + "/" + file;
        if(fs.lstatSync(curPath).isDirectory()) { // recurse
            deleteFolderRecursive(curPath);
        } else { // delete file
            fs.unlinkSync(curPath);
        }
        });
        fs.rmdirSync(path);
    }
};

deleteFolderRecursive(buildPath)
fs.mkdirSync(buildPath)

const originContent = fs.readFileSync(srcPath.concat('index.js'), {encoding: 'utf8'})

glob.sync(srcPath.concat('*/*.vue')).forEach((path) => {
    const pageName = path.replace(srcPath,'').split('/')[0]
    const content = originContent.replace('./App.vue','.' + path)
    fs.writeFileSync(buildPath.concat(pageName + '.js'), Buffer.from(content, {encoding: 'utf8'}))
}, {})
//***************** */

module.exports = {
  entry: 
    glob.sync(buildPath + '*.js').reduce((acc, path) => {
        const entry = path.replace('.js','').replace(buildPath,'./')
        acc[entry] = path
        return acc
    }, {})
  ,

  output: {
    filename: '[name]/index.js',
    path: __dirname + '/../src/main/resources/static/js'
  },

  module: {
    rules: [
      {
        test: /\.vue$/,
        loader: 'vue-loader'
      },
      {
        test: /\.js$/,
        loader: 'babel-loader'
      },
      {
        test: /\.css$/,
        use: [
          'vue-style-loader',
          'css-loader'
        ]
      }
    ]
  },
  plugins: [
    new VueLoaderPlugin()
  ]
};