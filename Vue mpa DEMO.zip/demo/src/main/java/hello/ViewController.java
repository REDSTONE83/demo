package hello;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class ViewController {

    @GetMapping("/view/{pageName}")
    public String view(@PathVariable String pageName, Model model) {
        // pageName 유효성 검사를 넣으면 되겠지? 아니면 이 컨트롤러 이전에 URL 권한 체크?
        model.addAttribute("name", pageName);
        return "template";
    }
}