<template>
    <div>
        <div style="width:600px; overflow-x:scroll; margin:auto;">
            <div class="container" v-bind:style="{width: columnswidth+'px'}" 
                @wheel="scrollContent($event)">
                <div class="header" v-bind:style="{width: columnswidth+'px'}">
                    <template v-for="(column, index) in columns">
                        <div class="header-cell" v-bind:style="{width: column.width+'px'}"
                            v-bind:key="index">
                            <span> {{column.name}} </span>
                        </div>
                    </template>
                </div>
                <div class="content" v-bind:style="{width: columnswidth+'px'}">
                    <template v-for="(data, dataidx) in renderlist">
                        <template v-for="(column, columnidx) in columns">
                            <div class="cell" v-bind:style="{width: column.width+'px'}" 
                                v-bind:key="(dataidx*100)+columnidx">
                                <span> {{data[column.name]}} </span>
                            </div>
                        </template>
                    </template>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "Grid",
    props: ["dataset"],
    data: function () {
        return {
            columns:[
                { name: "name", width: 250 },
                { name: "age", width: 50 },
                { name: "sex", width: 50 },
                { name: "salary", width: 150 },
                { name: "name2", width: 250 },
                { name: "age2", width: 50 },
                { name: "sex2", width: 50 },
                { name: "salary2", width: 150 },
                { name: "name", width: 250 },
                { name: "age", width: 50 },
                { name: "sex", width: 50 },
                { name: "salary", width: 150 },
                { name: "name", width: 250 },
                { name: "age", width: 50 },
                { name: "sex", width: 50 },
                { name: "salary", width: 150 },
                { name: "name", width: 250 },
                { name: "age", width: 50 },
                { name: "sex", width: 50 },
                { name: "salary", width: 150 },
                { name: "name", width: 250 },
                { name: "age", width: 50 },
                { name: "sex", width: 50 },
                { name: "salary", width: 150 },
                { name: "name", width: 250 },
                { name: "age", width: 50 },
                { name: "sex", width: 50 },
                { name: "salary", width: 150 }
            ],
            contentTop:0,
            renderlist: []
        }
    },
    mounted: function () {
        this.render();
    },
    computed: {
        columnswidth: function () {
            var totalwidth = 0;
            for(var i = 0; i < this.columns.length; i++) {
                totalwidth += this.columns[i].width;
            }
            return totalwidth;
        },
    },
    watch: {
        contentTop: function() {
            this.render();
        }
    },
    methods: {
        scrollContent(event) {
            if(event.deltaY != 0) event.preventDefault();
            else return;

            if(event.deltaY < 0 && this.contentTop > 0) this.contentTop--;
            else if(event.deltaY > 0 && this.contentTop+20 < this.dataset.getLength()) this.contentTop++;
        },
        render() {
            this.renderlist = this.dataset.getRenderList(this.contentTop, 20);
        }
    },
}
</script>

<style>
.container {
    height: 620px;
    position: relative;
}

.header {
    position: absolute;
    top: 0;
}

.content {
    position: absolute;
    top: 30px;
}

.header-cell {
    height: 30px;
    float: left;
    background-color: aquamarine;
}

.cell {
    height: 30px;
    float: left;
}
</style>