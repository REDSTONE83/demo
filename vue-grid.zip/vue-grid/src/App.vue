<template>
  <div id="app">
    <button @click="modifyData">Modify Data</button>
    <Grid :dataset="dataset" />
  </div>
</template>

<script>
import Grid from './components/Grid.vue'
import { Dataset } from './dataset.js'

export default {
  name: 'app',
  components: {
    Grid
  },
  data: function() {
    return {
      dataset: null
    }
  },
  created: function() {
    var datalist = [];
    for(var i = 0; i < 1000000; i++) {
      datalist.push({
        name: "Name " + i,
        age: Math.round(Math.random() * 100),
        sex: Math.random() > 0.5 ? "M" : "F",
        salary: Math.round(Math.random() * 10000),
        name2: "Name2 " + i,
        age2: Math.round(Math.random() * 100),
        sex2: Math.random() > 0.5 ? "M" : "F",
        salary2: Math.round(Math.random() * 10000)
      })
    }

    this.dataset = new Dataset(datalist.slice(0,100));
  },
  methods: {
    modifyData: function() {
      this.dataset.setValue(0, "name", "Modified!!!");
    }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
