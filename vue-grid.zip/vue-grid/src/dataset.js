function Dataset(datalist){
    this.datalist = datalist;

    Object.preventExtensions(this);
}

Dataset.prototype.setValue = function (index, key, value) {
    this.datalist[index][key] = value;
}

Dataset.prototype.getLength = function () {
    return this.datalist.length;
}

Dataset.prototype.getRenderList = function (begin, size) {
    var end = begin + Math.min(size, this.datalist.length);
    return this.datalist.slice(begin, end);
}

export {Dataset}